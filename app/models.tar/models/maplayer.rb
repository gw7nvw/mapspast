class Maplayer < ActiveRecord::Base
end
