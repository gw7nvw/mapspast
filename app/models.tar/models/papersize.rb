class Papersize < ActiveRecord::Base
end
