class Projection < ActiveRecord::Base
end
