class Mapseries < ActiveRecord::Base
end
