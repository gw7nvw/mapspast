class Mapset < ActiveRecord::Base
end
