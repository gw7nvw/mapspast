module GdalHelper
end
