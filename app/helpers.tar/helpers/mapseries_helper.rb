module MapseriesHelper
end
