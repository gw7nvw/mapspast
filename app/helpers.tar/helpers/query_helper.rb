module QueryHelper
end
