class HelpController < ApplicationController

def show
   @name=params[:id]
end
end
