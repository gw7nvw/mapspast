class ArcgisController < ApplicationController
end
