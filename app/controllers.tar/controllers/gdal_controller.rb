class GdalController < ApplicationController

def index
end
end
